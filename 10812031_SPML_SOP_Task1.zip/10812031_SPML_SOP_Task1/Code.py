import matplotlib.image as image
import numpy as np
import matplotlib.pyplot as plt
img=image.imread('image_10.jpg')
print('The Shape of the image is:',img.shape)
#image array is stored as img
vertical_filter = np.array([np.array([np.array([1,0,-1]),np.array([1,0,-1]),np.array([1,0,-1]) ]),np.array([np.array([1,0,-1]),np.array([1,0,-1]),np.array([1,0,-1]) ]),np.array([np.array([1,0,-1]),np.array([1,0,-1]),np.array([1,0,-1]) ])])
print(vertical_filter, 'is a kernel for detecting vertical edges')
  
horizontal_filter = np.array([np.array([np.array([1,1,1]),np.array([0,0,0]),np.array([-1,-1,-1])]),np.array([np.array([1,1,1]),np.array([0,0,0]),np.array([-1,-1,-1])]),np.array([np.array([1,1,1]),np.array([0,0,0]),np.array([-1,-1,-1])])])
print(horizontal_filter, 'is a kernel for detecting horizontal edges')
def apply_kernel(img, kernel):
    return np.sum(np.multiply(img, kernel))
  
# Visualizing img
plt.imshow(img)
plt.axis('off')
plt.title('img1')
plt.show()
  
# Checking for horizontal and vertical features in image1
print('Horizontal edge confidence score:', apply_kernel(img,horizontal_filter))
print('Vertical edge confidence score:', apply_kernel(img,vertical_filter))
#To convolve...we slide the certical and horizontal filters over the given image and convolve to get a output
#the output patrix will be of dimensions ((n-f+2p)/s + 1)x  ((n-f+2p)/s + 1)..here we didnt add any padding so p=0...and we take stride to be 1.n=dimensions of imput matrix and f is the dimensions of filter
#Now we do max pool to this convolved layer and get a matrix of reduced dimensions ((n-f+2p)/s + 1)x  ((n-f+2p)/s + 1) ,n=dimensions of imput matrix and f is the dimensions of filter
#Now we repeat the convolution and max pooling step twice
#Now we flatten the final matrix into mx1 matrix and apply find the fully connected layer...
#finally the fully connected layer is made to undergo softmax
#now the output is categorised as cracked or not and is looped several times and the best outpt is found through gradient descent

  



